package vn.iostar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example3CategoryProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(Example3CategoryProductApplication.class, args);
	}

}
