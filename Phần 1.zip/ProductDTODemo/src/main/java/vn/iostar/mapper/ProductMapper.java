package vn.iostar.mapper;

import org.springframework.stereotype.Component;
import vn.iostar.dto.ProductDTO;
import vn.iostar.entity.Category;
import vn.iostar.entity.Product;

@Component
public class ProductMapper {

    public ProductDTO toDto(Product entity) {
        if (entity == null) return null;
        
        ProductDTO dto = new ProductDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setPrice(entity.getPrice());
        dto.setQuantity(entity.getQuantity());
        dto.setDescription(entity.getDescription());
        dto.setImages(entity.getImages());
        
        if (entity.getCategory() != null) {
            dto.setCategoryId(entity.getCategory().getId());
            dto.setCategoryName(entity.getCategory().getName());
        }
        
        return dto;
    }

    public Product toEntity(ProductDTO dto) {
        if (dto == null) return null;
        
        Product entity = new Product();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        entity.setPrice(dto.getPrice());
        entity.setQuantity(dto.getQuantity());
        entity.setDescription(dto.getDescription());
        entity.setImages(dto.getImages());
        
        if (dto.getCategoryId() != null) {
            Category category = new Category();
            category.setId(dto.getCategoryId());
            entity.setCategory(category);
        }
               return entity;
    }
    public void updateEntityFromDto(ProductDTO dto, Product entity) {
        if (dto == null || entity == null) return;
        
        entity.setName(dto.getName());
        entity.setPrice(dto.getPrice());
        entity.setQuantity(dto.getQuantity());
        entity.setDescription(dto.getDescription());
        
        // Cập nhật ảnh nếu DTO có tên ảnh mới
        if (dto.getImages() != null) {
            entity.setImages(dto.getImages());
        }
    }

}