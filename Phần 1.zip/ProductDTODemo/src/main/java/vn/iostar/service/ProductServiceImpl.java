package vn.iostar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import vn.iostar.dto.ProductDTO;
import vn.iostar.entity.Product;
import vn.iostar.mapper.ProductMapper;
import vn.iostar.repository.ProductRepository;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductMapper productMapper;

    // Đường dẫn thư mục lưu file
    private final Path uploadDir = Paths.get("uploads/products");

    @Override
    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll()
                .stream()
                .map(productMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public ProductDTO getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy sản phẩm với ID: " + id));
        return productMapper.toDto(product);
    }

    @Override
    public ProductDTO saveProduct(ProductDTO productDTO) {
        // 1. Kiểm tra nếu người dùng có chọn upload file ảnh mới
        if (productDTO.getImage() != null && !productDTO.getImage().isEmpty()) {
            try {
                String savedFileName = saveImage(productDTO.getImage());
                productDTO.setImages(savedFileName); // Gán tên file ảnh đã lưu vào DTO
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // 2. Chuyển DTO thành Entity và lưu vào CSDL
        Product product = productMapper.toEntity(productDTO);
        Product savedProduct = productRepository.save(product);
        return productMapper.toDto(savedProduct);
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    // Hàm phụ trợ lưu file ảnh vào ổ đĩa
    private String saveImage(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            return null;
        }
        
        // Tạo thư mục nếu chưa tồn tại
        Files.createDirectories(uploadDir);
        
        // Lấy tên file gốc và đuôi file (.jpg, .png, ...)
        String originalName = file.getOriginalFilename();
        String ext = (originalName != null && originalName.contains(".")) 
                      ? originalName.substring(originalName.lastIndexOf(".")) : "";
        
        // Sinh tên file ngẫu nhiên bằng UUID để tránh trùng tên
        String fileName = UUID.randomUUID().toString() + ext;
        Path target = uploadDir.resolve(fileName);
        
        // Copy file vào thư mục target
        try (InputStream inputStream = file.getInputStream()) {
            Files.copy(inputStream, target, StandardCopyOption.REPLACE_EXISTING);
        }
        
        return fileName;
    }
}