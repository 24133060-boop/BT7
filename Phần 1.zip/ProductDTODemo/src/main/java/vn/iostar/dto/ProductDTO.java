package vn.iostar.dto;
import org.springframework.web.multipart.MultipartFile;

public class ProductDTO {
    private Long id;
    private String name;
    private Double price;
    private Integer quantity;
    private String description;
    
    private Long categoryId;
    private String categoryName;
    
    private String images;
    private MultipartFile image;

    public ProductDTO() {}

    public ProductDTO(Long id, String name, Double price, Integer quantity, String description, Long categoryId, String categoryName) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.description = description;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public MultipartFile getImage() {
        return image;
    }

    public void setImage(MultipartFile image) {
        this.image = image;
    }
}