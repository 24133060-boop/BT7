package vn.iostar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductDtoDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductDtoDemoApplication.class, args);
	}

}
